<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Arthur Oliveira Ferreira</title>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>

	<div class="jumbotron jumbotron-one">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-4 text-center">
					<img src="img/avatar.jpg" alt="..." class="img-circle img-thumbnail">
				</div>
				<div class="col-xs-12 col-sm-8 text-center">
					<h1 class="nome-geral">Arthur Oliveira Ferreira</h1>
					<hr class="style-hr"/>
					<a href="#" class="social-phone">
						<i class="fa fa-phone-square fa-3x" aria-hidden="true"></i>
						<span class="hidden-xs">(91) 9999-9999</span>
					</a>
					<a href="#" class="social-linkedin"><i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="social-facebook"><i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
    </div>

    <div class="jumbotron jumbotron-two">
    	<div class="container">
    		<div class="row">
    			<div class="col-xs-12 text-center">
    				<h5>Em caso de duvidas, contate-me em <a href="#" class="link-email">arthuroliveiraferreira@gmail.com</a></h5>
    			</div>
    		</div>
    	</div>
    </div>

    <div class="container">
    	<div class="row">
    		<div class="col-xs-12 col-md-4">
    			<div class="row">
    				<div class="col-xs-12">
    					<div class="new-header clearfix">
		    				<hr/>
		    				<h2>Sobre mim</h2>
		    			</div>
		    			<p style="margin-bottom:0;">
			    			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			    			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			    			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			    			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			    			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			    			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		    			</p>
    				</div>
    				<div class="col-xs-12 col-sm-6 col-md-12 div-terceira">
    					<div class="new-header clearfix">
		    				<hr/>
		    				<h2>Educação</h2>
		    			</div>
		    			<address class="new-educacao">
						<h4 class="text-muted">Tecnologia da Informação</h4>
							Instituto de Ensino Superiores da Amazônia - IESAM<br>
							<strong>Graduação</strong>. 2005 – 2009<br>
						</address>
						<address class="new-educacao" style="margin-bottom:0;">
						<h4 class="text-muted">Especialização Web Management</h4>
							Instituto de Ensino Superiores da Amazônia - IESAM<br>
							<strong>Pós-Graduação</strong>. 2012 – 2013<br>
						</address>
    				</div>
    				<div class="col-xs-12 col-sm-6 col-md-12 div-terceira">
    					<div class="new-header clearfix">
		    				<hr/>
		    				<h2>Idiomas</h2>
		    			</div>
		    			<address class="new-educacao" style="float:left;width:50%;">
						<h4 class="text-muted">Português</h4>
							Fluente ou nativo
						</address>
						<address class="new-educacao" style="float:left;margin-bottom:0;width:50%;">
						<h4 class="text-muted">Inglês</h4>
							Nível básico
						</address>
    				</div>
    			</div>
    		</div>
    		<div class="col-xs-12 col-md-8 div-segunda">
    			<div class="row">
    				<div class="col-xs-12">
    					<div class="new-header clearfix">
		    				<hr/>
		    				<h2>Experiência Profissional</h2>
		    			</div>
		    			<dl class="dl-horizontal dl-experiencias">
		    				<dt>Jun/1999  -  Mar/1900</dt>
		    				<dd><span class="text-muted text-uppercase">Estagiario</span> - Nome do local bem grande para ver como fica.</dd>
		    				<dd>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</dd>
		    			</dl>
		    			<dl class="dl-horizontal dl-experiencias">
		    				<dt>Jun/1999  -  Mar/1900</dt>
		    				<dd><span class="text-muted text-uppercase">Estagiario</span> - Nome do local bem grande para ver como fica.</dd>
		    				<dd>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</dd>
		    			</dl>
		    			<dl class="dl-horizontal dl-experiencias">
		    				<dt>Jun/1999  -  Mar/1900</dt>
		    				<dd><span class="text-muted text-uppercase">Estagiario</span> - Nome do local bem grande para ver como fica.</dd>
		    				<dd>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</dd>
		    			</dl>
		    			<dl class="dl-horizontal dl-experiencias" style="margin-bottom:0;">
		    				<dt>Jun/1999  -  Mar/1900</dt>
		    				<dd><span class="text-muted text-uppercase">Estagiario</span> - Nome do local bem grande para ver como fica.</dd>
		    				<dd>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</dd>
		    			</dl>
    				</div>
    				<div class="col-xs-12 div-terceira">
    					<div class="new-header clearfix">
		    				<hr/>
		    				<h2>Competências</h2>
		    			</div>
		    			<div class="row">
		    				<div class="col-xs-12 col-sm-6 div-competencia">
		    					<i class="fa fa-terminal fa-2x" aria-hidden="true"></i>
		    					<div class="progress">
		    						<div class="progress-bar progress-bar-dark" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
		    							PHP
		    						</div>
		    					</div>
		    				</div>
		    				<div class="col-xs-12 col-sm-6 div-competencia">
		    					<i class="fa fa-wordpress fa-2x" aria-hidden="true"></i>
		    					<div class="progress">
		    						<div class="progress-bar progress-bar-dark" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
		    							Mysql
		    						</div>
		    					</div>
		    				</div>
		    				<div class="col-xs-12 col-sm-6 div-competencia">
		    					<i class="fa fa-joomla fa-2x" aria-hidden="true"></i>
		    					<div class="progress">
		    						<div class="progress-bar progress-bar-dark" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
		    							Windows Server
		    						</div>
		    					</div>
		    				</div>
		    				<div class="col-xs-12 col-sm-6 div-competencia">
		    					<i class="fa fa-hashtag fa-2x" aria-hidden="true"></i>
		    					<div class="progress">
		    						<div class="progress-bar progress-bar-dark" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
		    							Linux
		    						</div>
		    					</div>
		    				</div>
		    				<div class="col-xs-12 col-sm-6 div-competencia">
		    					<i class="fa fa-bug fa-2x" aria-hidden="true"></i>
		    					<div class="progress">
		    						<div class="progress-bar progress-bar-dark" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
		    							Linux
		    						</div>
		    					</div>
		    				</div>
		    				<div class="col-xs-12 col-sm-6 div-competencia">
		    					<i class="fa fa-cloud fa-2x" aria-hidden="true"></i>
		    					<div class="progress">
		    						<div class="progress-bar progress-bar-dark" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
		    							Linux
		    						</div>
		    					</div>
		    				</div>
		    				<div class="col-xs-12 col-sm-6 div-competencia">
		    					<i class="fa fa-database fa-2x" aria-hidden="true"></i>
		    					<div class="progress">
		    						<div class="progress-bar progress-bar-dark" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
		    							Linux
		    						</div>
		    					</div>
		    				</div>
		    				<div class="col-xs-12 col-sm-6 div-competencia">
		    					<i class="fa fa-futbol-o fa-2x" aria-hidden="true"></i>
		    					<div class="progress">
		    						<div class="progress-bar progress-bar-dark" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
		    							Linux
		    						</div>
		    					</div>
		    				</div>
		    			</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>

    <footer>
    	<div class="container">
    		<p>&#169; <?=date('Y')?> Todos os direitos reservados. Desenvolvidor por <a href="mailto:xpcassio@gmail.com?Subject=Desenvolvimento%20de%20Websites%20e%20Sistemas" target="_top">xpcassio</a></p>
    	</div>
    </footer>

	<script src="js/jquery-2.2.3.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/geral.js"></script>
</body>
</html>