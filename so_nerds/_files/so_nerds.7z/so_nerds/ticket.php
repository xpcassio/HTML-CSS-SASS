<?php
require_once($_SERVER['DOCUMENT_ROOT']."/class/class.usuarioDB.php");
require_once($_SERVER['DOCUMENT_ROOT']."/class/class.profissionalDB.php");

session_start();

$oUsuarioDB = new usuarioDB();
$oProfissionalDB = new profissionalDB();

if (isset($_SESSION['usuario']) || isset($_SESSION['senha']) || isset($_SESSION['tipo'])) {
	$controle_login = true;
	$retorno = ($_SESSION['tipo'] == "usuario") ? $oUsuarioDB->login(array($_SESSION['usuario'],$_SESSION['senha'])) : $oProfissionalDB->login(array($_SESSION['usuario'],$_SESSION['senha']));
	$controle_tipo = $_SESSION['tipo'];
}
else {
	$controle_login = false;
	$retorno = false;
	$controle_tipo = '';
}

$temp_ticket_id = (isset($_GET['ticket'])) ? $_GET['ticket'] : "000000";
?>

<!DOCTYPE>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title>SO Nerds - Ticket</title>

	<!-- Arquivos CSS
	=================================== -->
	<? include_once("inc/inc_css.php"); ?>
</head>
<body>

	<div class="top_header">
		<div class="container">
			<div class="row">
				<div class="col-xs-4">
					<a href="/"><img src="img/logo.png" alt="logo"></a>
					Bem Vindo ao SO Nerds
				</div>
				<?php if (!$controle_login) { ?>
					<div class="col-xs-8 text-right">
						<form id="formLogin" class="form-inline" novalidate>
							<div class="form-group">
								<label class="sr-only">Login</label>
								<input type="text" class="form-control" name="usuario" placeholder="Usuario" required>
							</div>
							<div class="form-group">
								<label class="sr-only">Senha</label>
								<input type="password" class="form-control" name="senha" placeholder="Senha" required>
							</div>
							<a class="btn btn-default btn-login" role="button" href="javascript:;" data-loading-text='<i class="fa fa-circle-o-notch fa-spin fa-fw"></i>'>Log in</a>
						</form>
					</div>
				<?php } else { ?>
					<div class="col-xs-8 text-right">
						<button type="button" class="btn btn-lg btn-link btn-logout">
							<i class="fa fa-sign-out" aria-hidden="true"></i>
						</button>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>

	<?php
	require_once($_SERVER['DOCUMENT_ROOT']."/class/class.suporteDB.php");
	$oSuporteDB = new suporteDB();

	$retorno_ticket = $oSuporteDB->getTicket(array($temp_ticket_id));

	// caso exista o ticket
	if ($retorno_ticket != false) {
		$temp_lock = false;
		switch ($retorno_ticket->status) {
			case 'aberto':
				$temp_label = ($retorno != false && $retorno_ticket->usuarios_id == $retorno->id) ? '<span class="label label-primary">Aberto</span>' : "" ; break;
			case 'fechado':
				$temp_label = ($retorno != false && $retorno_ticket->usuarios_id == $retorno->id) ? '<span class="label label-danger">Fechado</span>' : "" ; break;
			case 'finalizado':
				$temp_label = ($retorno != false && $retorno_ticket->usuarios_id == $retorno->id) ? '<span class="label label-success">Finalizado</span>' : "" ; break;
		}
		$temp_btn_int = ($retorno != false && $retorno_ticket->usuarios_id == $retorno->id) ? "" : 'disabled="disabled"';
		$temp_dono_ticket = ($retorno != false && $retorno_ticket->usuarios_id == $retorno->id) ? true : false;
		$temp_icon_int = ($retorno != false && $retorno_ticket->usuarios_id == $retorno->id) ? '<img class="icon-usuario" src="img/usuario.png"> '.$retorno->nome : '';
		$temp_btn_responder = ($retorno_ticket->status == "aberto") ? '' : 'display: none;' ;
		$temp_btn_reabrir = ($retorno_ticket->status != "aberto" && $retorno_ticket->status == "finalizado") ? '' : 'display: none;';
		$temp_btn_finalizar = ($retorno_ticket->status == "aberto") ? '' : 'display: none;' ;
	}
	// caso nao exista
	else {
		$temp_lock = true;
		$temp_label = false;
		$temp_btn_int = 'disabled="disabled"';
		$temp_dono_ticket = false;
		$temp_icon_int = "";
		$temp_btn_responder = "";
		$temp_btn_reabrir = "";
		$temp_btn_finalizar = "";
	}

	// fix profissional de ti
	if ($retorno_ticket != false && $controle_tipo == "profissional") {
		switch ($retorno_ticket->status) {
			case 'aberto':
				$temp_label = ($retorno != false) ? '<span class="label label-primary">Aberto</span>' : "" ; break;
			case 'fechado':
				$temp_label = ($retorno != false) ? '<span class="label label-danger">Fechado</span>' : "" ; break;
			case 'finalizado':
				$temp_label = ($retorno != false) ? '<span class="label label-success">Finalizado</span>' : "" ; break;
		};
		$temp_btn_int = ($retorno != false) ? "" : 'disabled="disabled"';
		$temp_dono_ticket = ($retorno != false) ? true : false;
		$temp_icon_int = '<img class="icon-profissional" src="img/profissional.png"> Profissional TI';
	}
	?>

	<div class="jumbotron jumbotron-suporte overlay">
		<div class="container text-center">
			<div class="col-xs-8 col-xs-offset-2">
				<h2>Ticket #<?=$temp_ticket_id?> <?=$temp_label?></h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua.</p>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-xs-3 col-xs-offset-2" style="padding-top: 11px;">
				<?=$temp_icon_int?>
			</div>
			<div class="col-xs-4 col-xs-offset-1">
				<input class="btn btn-lg btn-block btn-default btn-interacao" type="button" value="Adicionar Interação" <?=$temp_btn_int?>>
			</div>
			<!-- FORMULARIO -->
			<div id="div_add_int" class="col-xs-8 col-xs-offset-2">
				<form id="formInteracao" novalidate>
					<div class="form-group">
						<label class="sr-only"></label>
						<textarea class="form-control input-lg" rows="5" name="interacao" placeholder="Descreva sua interação..." required></textarea>
					</div>

					<input type="hidden" name="suporte_id" value="<?=$temp_ticket_id?>">
					<input type="hidden" name="tipo" value="<?=$controle_tipo?>">
				</form>

				<div id="filelist_upload">
					<ul class="list-group list-group-download">
						<!-- <li class="list-group-item">
							<i class="fa fa-lg fa-file-o" aria-hidden="true"></i>
							nome_do_arquiv.pdf
							<a href="#"><i class="fa fa-trash fa-lg" aria-hidden="true"></i></a>
						</li> -->
					</ul>
				</div>

				<div id="container_upload" class="text-right">
					<button id="pickfiles" class="btn btn-lg btn-default" type="submit"><i class="fa fa-upload" aria-hidden="true"></i> Upload Arquivo</button>
					<button class="btn btn-responder btn-lg btn-default" type="submit" style="<?=$temp_btn_responder?>">Responder</button>
					<button class="btn btn-reabrir btn-lg btn-primary" type="submit" style="<?=$temp_btn_reabrir?>">Reabrir</button>
					<button class="btn btn-finalizar btn-lg btn-success" type="submit" style="<?=$temp_btn_finalizar?>">Finalizar</button>
				</div>

				<div id="div_alertGeral">
					<div class="alert" role="alert"></div>
				</div>
			</div>
			<!-- INTERAÇOES -->
			<div class="col-xs-8 col-xs-offset-2" style="margin-top: 20px;">
				<hr class="style17">
			</div>

			<?php if ($temp_lock || !$temp_dono_ticket) { ?>
			<div class="col-xs-8 col-xs-offset-2">
				<div class="well well-lock text-center">
					<i class="fa fa-lock" aria-hidden="true"></i>
				</div>
			</div>
			<?php } else {
			require_once($_SERVER['DOCUMENT_ROOT']."/class/class.ticketDB.php");
			$oTicketDB = new ticketDB();

			$recupera_all = $oTicketDB->all(array($temp_ticket_id));

			if ($recupera_all != false) {
				foreach ($recupera_all as $key => $value) {
					$temp_nome = ($value->tipo == "usuario") ? $retorno_ticket->nome : "Profissional TI";
					$temp_text_position = ($value->tipo == "usuario") ? "text-left" : "text-right";
					$temp_well = ($value->tipo == "usuario") ? "" : "well";
			?>

			<div class="col-xs-8 col-xs-offset-2 <?=$temp_well?>" style="margin-top: 20px;margin-bottom: 20px;">
				<div class="media media-interacao">
					<?php if($value->tipo == "usuario") { ?>
					<div class="media-left">
						<img class="media-object" src="img/usuario.png" alt="...">
					</div>
					<?php } ?>

					<div class="media-body">
						<h5 class="media-heading <?=$temp_text_position?>">
							<i class="fa fa-calendar" aria-hidden="true"></i> 99/99/9999
							<i class="fa fa-user" aria-hidden="true"></i> <?=$temp_nome?>
						</h5>
						<p class="<?=$temp_text_position?>"><?=$value->interacao?></p>
						<?php
						// verificando os anexos
						$temp_dir = $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR."so_nerds".DIRECTORY_SEPARATOR."upload";
						if (is_dir($temp_dir.DIRECTORY_SEPARATOR.$value->anexos)) {
							$temp_new_dir = $temp_dir.DIRECTORY_SEPARATOR.$value->anexos;

							echo "<hr>";

							$temp_dir_scan = array_diff(scandir($temp_new_dir), array('..', '.'));

							foreach ($temp_dir_scan as $key => $value1) {
								echo '<a href="javascript:;" class="link-download '.$temp_text_position.'" data-caminho="'.$temp_new_dir.DIRECTORY_SEPARATOR.$value1.'"><i class="fa fa-file-o" aria-hidden="true"></i> '.$value1.'</a>';
							}
						}
						?>
					</div>

					<?php if($value->tipo == "profissional") { ?>
					<div class="media-right">
						<img class="media-object" src="img/profissional.png" alt="...">
					</div>
					<?php } ?>
				</div>
			</div>

			<?php } } ?>

			<div class="col-xs-8 col-xs-offset-2" style="margin-top: 20px;">
				<div class="media media-interacao">
					<div class="media-left">
						<img class="media-object" src="img/usuario.png" alt="...">
					</div>
					<div class="media-body">
						<h5 class="media-heading">
							<i class="fa fa-calendar" aria-hidden="true"></i> 99/99/9999
							<i class="fa fa-user" aria-hidden="true"></i> <?=$retorno_ticket->nome?>
						</h5>
						<p class=""><strong><?=$retorno_ticket->assunto?></strong></p>
						<?php if ($retorno_ticket->hardware == 1) { echo '<p><i class="fa fa-check-square-o" aria-hidden="true"></i><strong>Hardware:</strong> '.$retorno_ticket->problema_hardware.'</p>'; }?>
						<?php if ($retorno_ticket->software == 1) { echo '<p><i class="fa fa-check-square-o" aria-hidden="true"></i><strong>Software:</strong> '.$retorno_ticket->problema_software.'</p>'; }?>
						<p><?=$retorno_ticket->mensagem?></p>
						<?php
						// verificando os anexos
						$temp_dir = $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR."so_nerds".DIRECTORY_SEPARATOR."upload";
						if (is_dir($temp_dir.DIRECTORY_SEPARATOR.$retorno_ticket->anexos)) {
							$temp_new_dir = $temp_dir.DIRECTORY_SEPARATOR.$retorno_ticket->anexos;

							echo "<hr>";

							$temp_dir_scan = array_diff(scandir($temp_new_dir), array('..', '.'));
							foreach ($temp_dir_scan as $key => $value) {
								echo '<a href="javascript:;" class="link-download" data-caminho="'.$temp_new_dir.DIRECTORY_SEPARATOR.$value.'"><i class="fa fa-file-o" aria-hidden="true"></i> '.$value.'</a>';
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-8">
					<p>Copyright © <?=date("Y");?>. Proibida reprodução ou utilização a qualquer título, sob as penas da lei.</p>
				</div>
				<div class="col-xs-4 text-right" style="margin-top: 9px;">
					<a href="#" class="link-social"><i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-youtube-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
	</footer>

	<!-- Arquivos Jsvascript
	=================================== -->
	<? include_once("inc/inc_js.php"); ?>
	<script type="text/javascript" src="js/plupload.full.min.js"></script>
	<script type="text/javascript" src="js/ticket.js"></script>

	<?php if (!$controle_login) { ?>

	<div class="modal fade" id="modalSuporte" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">
						<span class="text-danger"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> Area Restrita!</span>
					</h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-xs-12 text-modal">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		$('#modalSuporte').modal('show');
		$('#modalSuporte').on('hidden.bs.modal', function (e) {
			window.location.replace("/");
		});
	</script>

	<?php } ?>
</body>
</html>