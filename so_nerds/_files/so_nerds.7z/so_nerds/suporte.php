<?php
session_start();

if (isset($_SESSION['usuario']) || isset($_SESSION['senha']) || isset($_SESSION['tipo']))
	$controle_login = true;
else
	$controle_login = false;
?>
	
<!DOCTYPE>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title>SO Nerds - Suporte Online</title>

	<!-- Arquivos CSS
	=================================== -->
	<? include_once("inc/inc_css.php"); ?>
</head>
<body>

	<div class="top_header">
		<div class="container">
			<div class="row">
				<div class="col-xs-4">
					<a href="/"><img src="img/logo.png" alt="logo"></a>
					Bem Vindo ao SO Nerds
				</div>
				<?php if (!$controle_login) { ?>
					<div class="col-xs-8 text-right">
						<form id="formLogin" class="form-inline" novalidate>
							<div class="form-group">
								<label class="sr-only">Login</label>
								<input type="text" class="form-control" name="usuario" placeholder="Usuario" required>
							</div>
							<div class="form-group">
								<label class="sr-only">Senha</label>
								<input type="password" class="form-control" name="senha" placeholder="Senha" required>
							</div>
							<a class="btn btn-default btn-login" role="button" href="javascript:;" data-loading-text='<i class="fa fa-circle-o-notch fa-spin fa-fw"></i>'>Log in</a>
						</form>
					</div>
				<?php } else { ?>
					<div class="col-xs-8 text-right">
						<button type="button" class="btn btn-lg btn-link btn-logout">
							<i class="fa fa-sign-out" aria-hidden="true"></i>
						</button>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>

	<div class="jumbotron jumbotron-suporte overlay">
		<div class="container text-center">
			<!-- <div class="col-xs-12">
				<img src="img/logo.png" alt="logo">
			</div> -->
			<div class="col-xs-8 col-xs-offset-2">
				<h2>Ticket - Suporte Online</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua.</p>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<?php if ($controle_login && $_SESSION['tipo'] == "profissional") { ?>
				<div class="col-xs-8 col-xs-offset-2">
					<div class="alert alert-profissional alert-warning" role="alert">
						Erro para quando um <strong>profissional</strong> tiver logado!
					</div>
				</div>
			<?php } ?>

			<div class="col-xs-8 col-xs-offset-2">
				<form id="formTicket" novalidate>
					<div class="form-group">
						<label class="sr-only"></label>
						<input type="text" class="form-control input-lg" name="assunto" placeholder="Assunto" required>
					</div>
					<div class="form-group">
						<label class="sr-only"></label>
						<label class="checkbox-inline">
							<input type="checkbox" name="hardware" value="hardware"> Problemas com Hardware?
						</label>
						<label class="checkbox-inline">
							<input type="checkbox" name="software" value="software"> Problemas com Software?
						</label>
					</div>
					<div class="form-group">
						<label class="sr-only"></label>
						<select class="form-control input-lg" name="problema_hardware">
							<option value="" class="text-muted">-- Selecione seu problema de Hardware --</option>
							<option value="problema 1">problema 1</option>
							<option value="problema 1">problema 2</option>
							<option value="problema 1">problema 3</option>
							<option value="problema 1">problema 4</option>
							<option value="problema 1">problema 5</option>
						</select>
					</div>
					<div class="form-group">
						<label class="sr-only"></label>
						<select class="form-control input-lg" name="problema_software">
							<option value="" class="text-muted">-- Selecione seu problema de Software --</option>
							<option value="problema 1">problema 1</option>
							<option value="problema 1">problema 2</option>
							<option value="problema 1">problema 3</option>
							<option value="problema 1">problema 4</option>
							<option value="problema 1">problema 5</option>
						</select>
					</div>
					<div class="form-group">
						<label class="sr-only"></label>
						<textarea class="form-control input-lg" name="mensagem" rows="5" placeholder="Descreva seu problema..." required></textarea>
					</div>
				</form>
			</div>
			<div id="filelist_upload" class="col-xs-8 col-xs-offset-2">
				<ul class="list-group list-group-download">
					<!-- <li class="list-group-item">
						<i class="fa fa-lg fa-file-o" aria-hidden="true"></i>
						nome_do_arquiv.pdf
						<a href="#"><i class="fa fa-trash fa-lg" aria-hidden="true"></i></a>
					</li> -->
				</ul>
			</div>
			<?php if ($controle_login && $_SESSION['tipo'] == "usuario") { ?>

			<div id="container_upload" class="col-xs-8 col-xs-offset-2 text-right">
				<button id="pickfiles" class="btn btn-lg btn-default" type="submit"><i class="fa fa-upload" aria-hidden="true"></i> Upload Arquivo</button>
				<button id="uploadfiles" class="btn btn-lg btn-default" type="submit">Abrir Ticket</button>
			</div>
			<div class="col-xs-8 col-xs-offset-2" id="div_alertGeral">
				<div class="alert" role="alert"></div>
			</div>

			<?php } ?>
		</div>
	</div>

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-8">
					<p>Copyright © <?=date("Y");?>. Proibida reprodução ou utilização a qualquer título, sob as penas da lei.</p>
				</div>
				<div class="col-xs-4 text-right" style="margin-top: 9px;">
					<a href="#" class="link-social"><i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-youtube-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
	</footer>

	<!-- Arquivos Jsvascript
	=================================== -->
	<? include_once("inc/inc_js.php"); ?>
	<script type="text/javascript" src="js/plupload.full.min.js"></script>
	<script type="text/javascript" src="js/suporte.js"></script>

	<?php if (!$controle_login) { ?>

	<div class="modal fade" id="modalSuporte" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">
						<span class="text-danger"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> Area Restrita!</span>
					</h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-xs-12 text-modal">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		$('#modalSuporte').modal('show');
		$('#modalSuporte').on('hidden.bs.modal', function (e) {
			window.location.replace("/");
		});
	</script>

	<?php } ?>
</body>
</html>