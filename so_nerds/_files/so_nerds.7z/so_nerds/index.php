<?php
session_start();

if (isset($_SESSION['usuario']) || isset($_SESSION['senha']) || isset($_SESSION['tipo']))
	$controle_login = true;
else
	$controle_login = false;

?>

<!DOCTYPE>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title>SO Nerds</title>

	<!-- Arquivos CSS
	=================================== -->
	<? include_once("inc/inc_css.php"); ?>
</head>
<body>

	<div class="top_header">
		<div class="container">
			<div class="row">
				<div class="col-xs-4">
					<a href="/"><img src="img/logo.png" alt="logo"></a>
					Bem Vindo ao SO Nerds
				</div>
				<?php if (!$controle_login) { ?>
					<div class="col-xs-8 text-right">
						<form id="formLogin" class="form-inline" novalidate>
							<div class="form-group">
								<label class="sr-only">Login</label>
								<input type="text" class="form-control" name="usuario" placeholder="Usuario" required>
							</div>
							<div class="form-group">
								<label class="sr-only">Senha</label>
								<input type="password" class="form-control" name="senha" placeholder="Senha" required>
							</div>
							<a class="btn btn-default btn-login" role="button" href="javascript:;" data-loading-text='<i class="fa fa-circle-o-notch fa-spin fa-fw"></i>'>Log in</a>
						</form>
					</div>
				<?php } else { ?>
					<div class="col-xs-8 text-right">
						<button type="button" class="btn btn-lg btn-link btn-logout">
							<i class="fa fa-sign-out" aria-hidden="true"></i>
						</button>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>

	<div class="jumbotron overlay">
		<div class="container text-center">
			<!-- <div class="col-xs-12">
				<img src="img/logo.png" alt="logo">
			</div> -->
			<div class="col-xs-8 col-xs-offset-2">
				<h2>Lorem ipsum dolor sit amet</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation.</p>
			</div>
			<div class="col-xs-6 col-xs-offset-3">
				<a href="suporte.php" role="button" class="btn btn-lg btn-block btn-default" style="margin-top: 20px;">Default</a>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section-title text-center">
		            <h1>Lorem ipsum dolor</h1>
		            <h2>Consectetur adipisicing elit</h2>
		        </div>
			</div>
			<div class="col-xs-6">
        		<div class="media media-nerds">
        			<div class="media-left">
        				<i class="fa fa-list fa-4x" aria-hidden="true"></i>
        			</div>
        			<div class="media-body">
        				<h4 class="media-heading">Lorem ipsum dolor</h4>
        				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        			</div>
        		</div>
        		<div class="media media-nerds">
        			<div class="media-left">
        				<i class="fa fa-shopping-cart fa-4x" aria-hidden="true"></i>
        			</div>
        			<div class="media-body">
        				<h4 class="media-heading">Lorem ipsum dolor</h4>
        				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
        			</div>
        		</div>
        		<div class="media media-nerds">
        			<div class="media-left">
        				<i class="fa fa-percent fa-4x" aria-hidden="true"></i>
        			</div>
        			<div class="media-body">
        				<h4 class="media-heading">Lorem ipsum dolor</h4>
        				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        			</div>
        		</div>
			</div>
			<div class="col-xs-5 col-xs-offset-1">
				<form id="form_cadastro" novalidate>
					<div class="form-group">
						<label class="sr-only"></label>
						<input type="text" name="nome" class="form-control input-lg" placeholder="Nome completo" required>
					</div>
					<div class="form-group">
						<label class="sr-only"></label>
						<input type="text" name="email" class="form-control input-lg" placeholder="Email" required>
					</div>
					<div class="form-group">
						<label class="sr-only"></label>
						<input type="text" name="telefone" class="form-control input-lg" placeholder="Telefone" required>
					</div>
					<div class="form-group">
						<label class="sr-only"></label>
						<input type="password" name="senha" class="form-control input-lg" placeholder="Senha" required>
					</div>
					<div class="form-group">
						<div class="checkbox">
							<label>
								<input type="checkbox" name="envioEmail" value="sim" required>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit
							</label>
						</div>
					</div>
					<a class="btn btn-default btn-block btn-lg btn-cadastrar" role="button" href="javascript:;" data-loading-text='Aguarde...'>Cadastrar</a>
				</form>
			</div>
		</div>

		<div class="row div-cadastro" style="margin-top:50px;">
			<div class="col-xs-12">
				<div class="section-title text-center">
		            <h1>Lorem ipsum dolor</h1>
		            <h2>Consectetur adipisicing elit</h2>
		        </div>

		        <div class="row">
		        	<div class="col-xs-12">
		        		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		        		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		        		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		        		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		        		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		        		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		        	</div>
		        </div>
			</div>
		</div>
	</div>

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-8">
					<p>Copyright © <?=date("Y");?>. Proibida reprodução ou utilização a qualquer título, sob as penas da lei.</p>
				</div>
				<div class="col-xs-4 text-right" style="margin-top: 9px;">
					<a href="#" class="link-social"><i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-youtube-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i></a>
					<a href="#" class="link-social"><i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
	</footer>

	<div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Modal title</h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-xs-12 text-modal">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Arquivos Jsvascript
	=================================== -->
	<? include_once("inc/inc_js.php"); ?>
	<script type="text/javascript" src="js/index.js"></script>
</body>
</html>