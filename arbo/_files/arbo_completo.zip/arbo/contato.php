<!DOCTYPE html>
<html lang="pt-br">
<head>
	<?php include_once('inc/favicon.php'); ?>

	<!-- SOCIAL -->
	<meta property="og:title" content="Arbo - Contato" />
	<meta property="og:type" content="website" />
	<meta property="og:description" content="Importação, Projetos e Soluções Energéticas." />
	<meta property="og:url" content="http://www.arbo.eco.br/contato.php" />

	<meta property="og:image" content="http://www.arbo.eco.br/img/social.png" />
	<meta property="og:image:width" content="500" />
	<meta property="og:image:height" content="300" />

	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:image:alt" content="Banner logo Arbo">

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Arbo</title>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <?php include_once('inc/css.php'); ?>

    <script defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBslf0LIjnUGBGwn6tD4GF3wNiwaBp_p0M"></script>
</head>
<body>
	<div class="background background-pages">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<?php $temp_li_contato = "";include_once('inc/navbar.php'); ?>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-xs-12 text-center section-pages">
				<h1>Contato</h1>
				<span></span>
				<p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 col-md-6">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-12 div_endereco">
						<address>
							<strong>ARBO</strong><br>
							Rua Ó de Almeida 490 Conj. 1102<br>
							Belém, PA - Brasil<br>
							<i class="fa fa-phone"></i> <a href="tel:9140068800">(91) 4006-8800</a><br>
							<i class="fa fa-envelope"></i> <a href="mailto:contato@arbo.eco.br?Subject=Contato Website Arbo" target="_top">contato@arbo.eco.br</a>
						</address>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-12 div_mapa">
						<div id="map"></div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-6 div_form">
				<form id="formContato" novalidate>
					<div class="form-group">
						<input type="text" class="form-control input-lg" placeholder="Nome:" name="nome">
					</div>
					<div class="form-group">
						<input type="text" class="form-control input-lg" placeholder="Email:" name="email">
					</div>
					<div class="form-group">
						<input type="text" class="form-control input-lg" placeholder="Telefone:" name="telefone">
					</div>
					<div class="form-group">
						<textarea class="form-control input-lg" rows="5" placeholder="Mensagem:" name="mensagem"></textarea>
					</div>
					<button type="submit" class="btn btn-default btn-lg btn-block btn-formulario">Enviar</button>
				</form>
			</div>
			<div class="col-xs-12 div_alert">
				<div class="alert"></div>
			</div>
		</div>
	</div>

	<?php include_once('inc/footer.php'); ?>

	<?php include_once('inc/js.php'); ?>
	<script src="js/contato.js"></script>
</body>
</html>