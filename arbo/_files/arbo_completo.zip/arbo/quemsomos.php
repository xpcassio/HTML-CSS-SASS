<!DOCTYPE html>
<html lang="pt-br">
<head>
	<?php include_once('inc/favicon.php'); ?>

	<!-- SOCIAL -->
	<meta property="og:title" content="Arbo - Quem Somos" />
	<meta property="og:type" content="website" />
	<meta property="og:description" content="Importação, Projetos e Soluções Energéticas." />
	<meta property="og:url" content="http://www.arbo.eco.br/quemsomos.php" />

	<meta property="og:image" content="http://www.arbo.eco.br/img/social.png" />
	<meta property="og:image:width" content="500" />
	<meta property="og:image:height" content="300" />

	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:image:alt" content="Banner logo Arbo">

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Arbo</title>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <?php include_once('inc/css.php'); ?>
</head>
<body>
	<div class="background background-pages">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<?php $temp_li_quem = "";include_once('inc/navbar.php'); ?>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-xs-12 text-center section-pages">
				<h1>Quem Somos</h1>
				<span></span>
				<!-- <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p> -->
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12" style="margin-bottom: 50px;">
				<div class="row">
					<div class="col-xs-12 col-sm-6">
						<h2 class="headline">Empresa</h2>
						A Arbo é uma empresa genuinamente paraense, que possui como missão a expansão do uso da Energia Solar no norte e nordeste do país. Nosso objetivo é levar esta tecnologia e serviço a todos aqueles que desejam esta tecnologia de geração de energia limpa, produzindo sua própria energia elétrica.
					</div>
					<div class="col-xs-12 col-sm-6 text-right">
						<img class="img-headline img-responsive img-thumbnail" src="http://placehold.it/350x250">
					</div>
				</div>
			</div>

			<div class="col-xs-12" style="margin-bottom: 50px;">
				<div class="row">
					<!-- PARA DISPOSITIVOS MOVEIS -->
					<div class="visible-xs-block col-xs-12 col-sm-6">
						<h2 class="headline">Missão / Objetivos</h2>
						Nossa missão é mostrar para o maior número de pessoas, que é possível, ter uma energia de maior qualidade, menor preço e sem danificar o meio ambiente. Cada raio de sol que incide eu seu telhado, poderia estar sendo usado para ascender suas lâmpadas ou ligar o seu acondicionado. Pensando assim, da uma dó olhar pela janela e ver o quando de energia que está deixando de ser aproveitada. Nós podemos mudar isso.

						<div class="well well-sm well-tip" style="margin-top: 25px;">
							<div class="media">
								<div class="media-left">
									<i class="fa fa-exclamation-circle" aria-hidden="true"></i>
								</div>
								<div class="media-body">
									<h4 class="media-heading">Dicas Arbo:</h4>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
								</div>
							</div>
						</div>
					</div>
					<div class="visible-xs-block col-xs-12 col-sm-6 text-left">
						<img class="img-headline img-responsive img-thumbnail" src="http://placehold.it/350x250">
					</div>
					
					<!-- PARA TABLET E DESKTOP -->
					<div class="hidden-xs col-xs-12 col-sm-6 text-left">
						<img class="img-headline img-responsive img-thumbnail" src="http://placehold.it/350x250">
					</div>
					<div class="hidden-xs col-xs-12 col-sm-6">
						<h2 class="headline">Missão / Objetivos</h2>
						Nossa missão é mostrar para o maior número de pessoas, que é possível, ter uma energia de maior qualidade, menor preço e sem danificar o meio ambiente. Cada raio de sol que incide eu seu telhado, poderia estar sendo usado para ascender suas lâmpadas ou ligar o seu acondicionado. Pensando assim, da uma dó olhar pela janela e ver o quando de energia que está deixando de ser aproveitada. Nós podemos mudar isso.

						<div class="well well-sm well-tip" style="margin-top: 25px;">
							<div class="media">
								<div class="media-left">
									<i class="fa fa-exclamation-circle" aria-hidden="true"></i>
								</div>
								<div class="media-body">
									<h4 class="media-heading">Dicas Arbo:</h4>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xs-12">
				<div class="row">
					<div class="col-xs-12 col-sm-4 text-center">
						<div class="well">
							<h3 class="number-boxers">9999</h3>
							<span class="text-muted">Contador</span>
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 text-center">
						<div class="well">
							<h3 class="number-boxers">9999</h3>
							<span class="text-muted">Contador</span>
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 text-center">
						<div class="well">
							<h3 class="number-boxers">9999</h3>
							<span class="text-muted">Contador</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php include_once('inc/footer.php'); ?>

	<?php include_once('inc/js.php'); ?>
</body>
</html>