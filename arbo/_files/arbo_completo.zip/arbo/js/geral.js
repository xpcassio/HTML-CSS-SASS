$(document).ready(function() {
	$("a[href='#scrollTop']").click(function() {
		$("html, body").animate({ scrollTop: 0 }, "slow");
		return false;
	});
});