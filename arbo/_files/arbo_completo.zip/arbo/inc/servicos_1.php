<div class="col-xs-12">
	<div class="row">
		<div class="col-xs-12 col-md-4 margin-servico">
			Nas cidades e áreas atendidas pelas concessionárias de energia elétrica, utilizamos os sistemas chamados On-Grid que são conectados diretamente à rede de distribuição da concessionária local. São várias as vantagens da utilização desses sistemas e destacamos:
		</div>
		<!-- <div class="col-xs-12 col-md-8 nav-tab-box margin-servico">
			<ul class="nav nav-tabs text-center" role="tablist">
				<li role="presentation" class="active">
					<a href="#home" role="tab" data-toggle="tab">
						1º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#profile" role="tab" data-toggle="tab">
						2º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#messages" role="tab" data-toggle="tab">
						3º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#settings" role="tab" data-toggle="tab">
						4º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#settings1" role="tab" data-toggle="tab">
						5º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#settings2" role="tab" data-toggle="tab">
						6º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#settings3" role="tab" data-toggle="tab">
						7º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
			</ul>

			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="home">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="profile">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="messages">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="settings">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="settings1">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="settings2">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="settings3">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
			</div>
		</div> -->
		<div class="col-xs-12 col-md-8 nav-tab-box margin-servico">
			<ul>
				<li>Baixíssima manutenção.</li>
				<li>Possibilidade de gerar crédito de energia a ser utilizado em até 60 meses.</li>
				<li>Possibilidade de gerar crédito de energia para ser utilizado em outra unidade consumidora com o mesmo CPF/CNPJ.</li>
				<li>Possibilidade de criar cooperativas de geração de energia para compartilhar um único sistema gerador.</li>
				<li>Redução imediata da conta de energia.</li>
				<li>Longa duração do sistema (placas com garantias de até 25 anos)</li>
				<li>Valorização do imóvel.</li>
			</ul>
		</div>
	</div>
	<!-- <div class="row">
		<div class="col-xs-12 col-md-4 margin-servico">
			<div class="media media-arbo">
				<div class="media-left">
					<div class="bola">
						<i class="fa fa-envira" aria-hidden="true"></i>
					</div>
				</div>
				<div class="media-body">
					<h4 class="media-heading">Media heading</h4>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua.
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-4 margin-servico">
			<div class="media media-arbo">
				<div class="media-left">
					<div class="bola">
						<i class="fa fa-envira" aria-hidden="true"></i>
					</div>
				</div>
				<div class="media-body">
					<h4 class="media-heading">Media heading</h4>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua.
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-4 margin-servico">
			<div class="media media-arbo">
				<div class="media-left">
					<div class="bola">
						<i class="fa fa-envira" aria-hidden="true"></i>
					</div>
				</div>
				<div class="media-body">
					<h4 class="media-heading">Media heading</h4>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua.
				</div>
			</div>
		</div>
	</div> -->
</div>