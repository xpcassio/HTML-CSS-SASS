<div class="col-xs-12">
	<div class="row">
		<div class="col-xs-12 col-sm-6 col-md-4 margin-servico">
			Para grandes consumidores de energia como indústrias e comércios, o sistema utilizado é o On-Grid. Nesses casos, deve haver uma análise junto a concessionária local sobre os valores e modalidade contratadas para que a geração seja aproveitada em sua totalidade. As vantagens são várias e destacamos:
		</div>
		<!-- <div class="col-xs-12 col-sm-6 col-md-4 text-right margin-servico">
			<img class="img-headline img-responsive img-thumbnail" src="http://placehold.it/350x250">
		</div> -->
		<!-- <div class="col-xs-12 col-sm-12 col-md-4 margin-servico">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</div> -->
		<div class="col-xs-12 col-sm-6 col-md-4 nav-tab-box margin-servico">
			<ul>
				<li>Redução imediata no valor da conta de energia.</li>
				<li>Baixo custo de manutenção.</li>
				<li>Instalação rápida.</li>
				<li>Longa duração do sistema com garantias que chegam a até 25 anos.</li>
			</ul>
		</div>
		<div class="col-xs-12 col-md-4 margin-servico">
			<div class="media media-arbo">
				<div class="media-left">
					<span class="fa-stack fa-lg fa-2x">
						<i class="fa fa-circle fa-stack-2x"></i>
						<i class="fa fa-dollar fa-stack-1x fa-inverse"></i>
					</span>
				</div>
				<div class="media-body">
					<h4 class="media-heading">Investimento</h4>
					O investimento tem retorno em médio prazo, trazendo, ao longo da vida da empresa, uma redução significativa nos custos operacionais.
				</div>
			</div>
		</div>
	</div>
</div>