<div class="col-xs-12">
	<div class="row">
		<div class="col-xs-12 col-md-4 margin-servico">
			<p>Nos locais onde não existe uma rede de distribuição elétrica convencional, feita por uma distribuidora local, utilizamos o sistema chamado Of-Grid. Estes sistemas autônomos são utilizados para várias finalidades como:</p>
		</div>
		<!-- <div class="col-xs-12 col-md-8 nav-tab-box margin-servico">
			<ul class="nav nav-tabs text-center" role="tablist">
				<li role="presentation" class="active">
					<a href="#supertab" role="tab" data-toggle="tab">
						1º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#supertab1" role="tab" data-toggle="tab">
						2º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#supertab2" role="tab" data-toggle="tab">
						3º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#supertab3" role="tab" data-toggle="tab">
						4º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#supertab4" role="tab" data-toggle="tab">
						5º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#supertab5" role="tab" data-toggle="tab">
						6º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
				<li role="presentation">
					<a href="#supertab6" role="tab" data-toggle="tab">
						7º <span class="hidden-xs hidden-sm">Etapa</span>
					</a>
				</li>
			</ul>

			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="supertab">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="supertab1">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="supertab2">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="supertab3">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="supertab4">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="supertab5">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
				<div role="tabpanel" class="tab-pane" id="supertab6">
					<div class="row">
						<div class="col-xs-12">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
			</div>
		</div> -->
		<div class="col-xs-12 col-md-8 nav-tab-box margin-servico">
			<ul>
				<li>Iluminação.</li>
				<li>Ligação de aparelhos domésticos como: geladeiras, freezers, TVs, Ap. de som, computadores, entre outros.</li>
				<li>Bombeamento de água.</li>
				<li>Sistemas de segurança patrimoniais: cercas elétricas, alarmes, monitoramento, etc.</li>
			</ul>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 margin-servico">
			<div class="well well-sm well-tip">
				<div class="media">
					<div class="media-left">
						<i class="fa fa-exclamation-circle" aria-hidden="true"></i>
					</div>
					<div class="media-body">
						<h4 class="media-heading">Dicas Arbo:</h4>
						Diferentemente dos sistemas que utilizam geradores a combustão e que tem horários limitados para funcionamento, o sistema solar fotovoltaico pode ser utilizado por 24 hrs ao dia, desde que a utilização dos aparelhos na rede e o banco de baterias associado sejam bem equacionados.
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- <div class="row">
		<div class="col-xs-12 col-md-4 margin-servico">
			<div class="media media-arbo">
				<div class="media-left">
					<div class="bola">
						<i class="fa fa-bar-chart" aria-hidden="true"></i>
					</div>
				</div>
				<div class="media-body">
					<h4 class="media-heading">Media heading</h4>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua.
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-4 margin-servico">
			<div class="media media-arbo">
				<div class="media-left">
					<div class="bola">
						<i class="fa fa-bar-chart" aria-hidden="true"></i>
					</div>
				</div>
				<div class="media-body">
					<h4 class="media-heading">Media heading</h4>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua.
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-4 margin-servico">
			<div class="media media-arbo">
				<div class="media-left">
					<div class="bola">
						<i class="fa fa-bar-chart" aria-hidden="true"></i>
					</div>
				</div>
				<div class="media-body">
					<h4 class="media-heading">Media heading</h4>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua.
				</div>
			</div>
		</div>
	</div> -->
</div>