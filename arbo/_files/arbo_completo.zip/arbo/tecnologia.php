<!DOCTYPE html>
<html lang="pt-br">
<head>
	<?php include_once('inc/favicon.php'); ?>

	<!-- SOCIAL -->
	<meta property="og:title" content="Arbo - Tecnologia" />
	<meta property="og:type" content="website" />
	<meta property="og:description" content="Importação, Projetos e Soluções Energéticas." />
	<meta property="og:url" content="http://www.arbo.eco.br/tecnologia.php" />

	<meta property="og:image" content="http://www.arbo.eco.br/img/social.png" />
	<meta property="og:image:width" content="500" />
	<meta property="og:image:height" content="300" />

	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:image:alt" content="Banner logo Arbo">

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Arbo</title>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <?php include_once('inc/css.php'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
</head>
<body>
	<div class="background background-pages">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<?php $temp_li_tec = "";include_once('inc/navbar.php'); ?>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-xs-12 text-center section-pages">
				<h1>Tecnologia</h1>
				<span></span>
				<p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12">
				<p>Em se falando de ENERGIA SOLAR, existem dois modos de se aproveitar o que o Sol nos fornece diariamente:</p>
			</div>
			<div class="col-xs-12 col-sm-6">
				<div class="media media-arbo" style="margin-top: 35px;">
					<div class="media-left">
						<span class="fa-stack fa-lg fa-2x">
							<i class="fa fa-circle fa-stack-2x"></i>
							<strong class="fa-stack-1x" style="color: white;">1</strong>
						</span>
					</div>
					<div class="media-body">
						A primeira maneira é aproveitando o calor que ele fornece, captando este calor em placas ou outros modelos de captação existentes e transferindo este calor para um fluido (no caso residencial/comercial este fluido é a água) e o armazenando para utilização posterior. Este modelo é conhecido comercialmente como “Aquecimento Solar de água”.
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-6">
				<div class="media media-arbo" style="margin-top: 35px;">
					<div class="media-left">
						<span class="fa-stack fa-lg fa-2x">
							<i class="fa fa-circle fa-stack-2x"></i>
							<strong class="fa-stack-1x" style="color: white;">2</strong>
						</span>
					</div>
					<div class="media-body">
						A outra maneira é aproveitando a LUZ que o Sol nos fornece e transformando esta luz, através de placas solares fotovoltaicas, em ENERGIA ELÈTRICA para diversas utilizações em instalações residenciais e ou comerciais. Esta maneira é com a qual trabalhamos para fornecer aos nossos clientes soluções que atendam na medida seus consumos de energia elétrica.
					</div>
				</div>
			</div>
			<div class="col-xs-12">
				<p style="margin-top: 35px;">No Brasil a utilização de sistemas fotovoltaicos para geração de energia elétrica só se tornou viável a partir de abril de 2012 com a regulamentação, através da Resolução Normativa 482/2012 da ANEEL (Agencia Nacional de Energia Elétrica), dos limites e normas para conexão com o sistema nacional de distribuição. Em 01/03/2016 entrou em vigor a REN 687/2015 da ANEEL que alterou e aperfeiçoou alguns artigos da REN 482/2012, tornando este tipo de geração mais atraente e comercialmente viável. A geração fotovoltaica de energia elétrica pode ser feita de duas maneiras: On-grid e Off-Grid.</p>
			</div>

			<div class="col-xs-12 col-sm-6">
				<p style="margin-top: 35px;">Nos sistemas On-Grid, utilizamos placas solares, inversores de energia e sistemas de proteção, ligando-os diretamente a rede de distribuição da concessionária de energia elétrica local através de um medidor próprio que computa a quantidade de energia consumida da concessionária nos momentos de pouca luz e a quantidade que é entregue para a rede de distribuição nos momentos em que a geração local se torna maior do que o consumo existente no local, com isso, o consumidor irá pagar apenas a diferença do que for consumido, ou, nos caso de geração excedente, terá um crédito em KWh a ser utilizado num período de até 60 meses.</p>
			</div>
			<div class="col-xs-12 col-sm-6 text-right">
				<img class="img-headline img-responsive img-thumbnail" src="http://placehold.it/350x250" style="margin-top: 35px;">
			</div>

			<div class="col-xs-12 col-sm-6">
				<p style="margin-top: 35px;">Nos sistemas Of-grid, utilizamos placas solares, controladores de carga, inversores de energia, baterias e sistemas de proteção. Nestes sistemas, a energia não utilizada durante os momentos de incidência de luz solar é armazenada nas baterias para serem utilizadas posteriormente. São usados em áreas onde não há cobertura da rede de distribuição de energia elétrica.</p>
			</div>
			<div class="col-xs-12 col-sm-6 text-right">
				<img class="img-headline img-responsive img-thumbnail" src="http://placehold.it/350x250" style="margin-top: 35px;">
			</div>
		</div>

		<!-- <div class="row">
			<div class="col-xs-12 col-sm-6">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>
			<div class="col-xs-12 col-sm-6 text-right">
				<img class="img-headline img-responsive img-thumbnail" src="http://placehold.it/350x250">
			</div>
		</div> -->

		<!-- <div class="row">
			<div class="col-xs-12 margin-top-50">
				<div class="well well-sm well-tip">
					<div class="media">
						<div class="media-left">
							<i class="fa fa-exclamation-circle" aria-hidden="true"></i>
						</div>
						<div class="media-body">
							<h4 class="media-heading">Dicas Arbo:</h4>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
						</div>
					</div>
				</div>
			</div>
		</div> -->

		<div class="row">
			<div class="col-xs-12 text-center section-pages margin-top-50">
				<h1>O que vale mais a pena</h1>
				<span></span>
				<p class="text-muted">Colocar dinheiro na Poupança ou deixar de pagar conta de Luz?</p>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 col-sm-8">
				<div class="ct-chart"></div>
			</div>
			<div class="col-xs-12 col-sm-4 div-vantagens">
				<div class="row">
					<div class="col-xs-12 text-center">
						<h3>Vantagens da Energia Solar</h3>
					</div>
					<div class="col-xs-6 text-center" style="margin-bottom:15px;">
						<div class="bola">
							<i class="fa fa-university" aria-hidden="true"></i>
						</div>
						<h4 class="text-muted">Economia ja no 1º mes</h4>
					</div>
					<div class="col-xs-6 text-center" style="margin-bottom:15px;">
						<div class="bola">
							<i class="fa fa-money" aria-hidden="true"></i>
						</div>
						<h4 class="text-muted">Sem reajuste tarifario</h4>
					</div>
					<div class="col-xs-6 text-center">
						<div class="bola">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
						<h4 class="text-muted">Valorização do imovel</h4>
					</div>
					<div class="col-xs-6 text-center">
						<div class="bola">
							<i class="fa fa-heart" aria-hidden="true"></i>
						</div>
						<h4 class="text-muted">Vida util de 25 anos</h4>
					</div>
				</div>
			</div>
		</div>

		<!-- <div class="row">
			<div class="col-xs-12 text-center section-pages margin-top-50">
				<h1>Etapas</h1>
				<span></span>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 col-md-8 col-md-offset-2 nav-tab-box">
				Nav tabs
				<ul class="nav nav-tabs text-center" role="tablist">
					<li role="presentation" class="active">
						<a href="#home" role="tab" data-toggle="tab">
							1º <span class="hidden-xs">Etapa</span>
						</a>
					</li>
					<li role="presentation">
						<a href="#profile" role="tab" data-toggle="tab">
							2º <span class="hidden-xs">Etapa</span>
						</a>
					</li>
					<li role="presentation">
						<a href="#messages" role="tab" data-toggle="tab">
							3º <span class="hidden-xs">Etapa</span>
						</a>
					</li>
					<li role="presentation">
						<a href="#settings" role="tab" data-toggle="tab">
							4º <span class="hidden-xs">Etapa</span>
						</a>
					</li>
					<li role="presentation">
						<a href="#settings1" role="tab" data-toggle="tab">
							5º <span class="hidden-xs">Etapa</span>
						</a>
					</li>
				</ul>
				Tab panes
				<div class="tab-content">
					<div role="tabpanel" class="tab-pane active" id="home">
						<div class="row">
							<div class="col-xs-12">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane" id="profile">
						<div class="row">
							<div class="col-xs-12">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane" id="messages">
						<div class="row">
							<div class="col-xs-12">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane" id="settings">
						<div class="row">
							<div class="col-xs-12">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane" id="settings1">
						<div class="row">
							<div class="col-xs-12">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> -->

		<div class="row">
			<div class="col-xs-12 text-center section-pages margin-top-50">
				<h1>Perguntas Frequentes</h1>
				<span></span>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12" style="margin-bottom: 25px;">
				<div class="list-group">
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>1.</strong> Quais são as etapas e os prazos para ter Energia Solar?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> -->
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>2.</strong> Como é feita a manutenção dos painéis?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<p>Os geradores de energia fotovoltaica possuem a baixa necessidade de manutenção, sendo projetados para durar mais de 25 anos. Apenas é orientada a limpeza frequente dos módulos pois acumulam fuligem e podem reduzir a eficácia do sistema. A limpeza pode ser feita com água e sabão e também limpa vidros, utilizando um rodo e um pano.</p>
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select active clearfix">
						<span class="div1"><strong>3.</strong>  O que é o Sistema de Compensação de Energia Elétrica?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description">
						<div class="row">
							<div class="col-xs-12">
								<p>A Resolução Normativa ANEEL nº 482/2012 define o Sistema de Compensação como um arranjo no qual a energia ativa injetada por unidade consumidora com microgeração ou minigeração distribuída é cedida, por meio de empréstimo gratuito, à distribuidora local e posteriormente compensada com o consumo de energia elétrica ativa. Esse sistema é também conhecido pelo termo em inglês net metering. Nele, um consumidor de energia elétrica instala pequenos geradores em sua unidade consumidora (como, por exemplo, painéis solares fotovoltaicos ou pequenas turbinas eólicas) e a energia gerada é usada para abater o consumo de energia elétrica da unidade. Quando a geração for maior que o consumo, o saldo positivo de energia poderá ser utilizado para abater o consumo em outro posto tarifário ou na fatura do mês subsequente. Os créditos de energia gerados continuam válidos por 60 meses. Há ainda a possibilidade de o consumidor utilizar esses créditos em outras unidades previamente cadastradas dentro da mesma área de concessão e caracterizada como autoconsumo remoto, geração compartilhada ou integrante de empreendimentos de múltiplas unidades consumidoras (condomínios).</p>
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>4.</strong> Todos os consumidores podem aderir ao Sistema de Compensação de Energia Elétrica?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<p>Não. A adesão ao sistema de compensação de energia elétrica não se aplica aos consumidores livres ou especiais, apenas aos cativos, que não têm a opção pela escolha do fornecedor de energia elétrica.</p>
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>5.</strong>  Os painéis fotovoltaicos são resistentes?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<p> Sim. Atualmente os painéis fotovoltaicos de boa qualidade geralmente são feitos com vidro temperado ou acrílico para proteger as células fotovoltaicas que ficam embaixo. Em condições variáveis de teste e experiências reais os módulos podem suportar as mais diversas formas de chuva de granizo.</p>
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>6.</strong> Posso compensar meus  créditos de energia em outro endereço?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<p>Pode! Com a nova revisão 687 da Aneel você poderá compensar seus créditos de energia em outro endereço, sem que a conta de luz precise estar sob o mesmo CPF ou CNPJ que o da unidade geradora. Para isso, será preciso comprovar o vínculo entre os titulares.</p>
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>7.</strong> É necessaria uma visita técnica antes da instalação?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> -->
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>8.</strong> Como posso pagar meu sistema?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> -->
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>9.</strong> Em quanto tempo vou recuperar o valor investido?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> -->
							</div>
						</div>
					</div>
					<a href="javascript:;" class="list-group-item list-group-select clearfix">
						<span class="div1"><strong>10.</strong> Quanto o meu sistema vai gerar por mês?</span>
						<span class="div2 text-right"><i class="fa fa-plus" aria-hidden></i></span>
					</a>
					<div class="list-group-item list-group-description" style="display: none;">
						<div class="row">
							<div class="col-xs-12">
								<p>A geração do sistema vai depender da irradiação da cidade onde você mora. Mas fique tranquilo, podemos personalizar seu sistema para que atenda exatamente sua necessidade energética.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-6 col-sm-offset-3">
				<a href="contato.php" class="btn btn-default btn-lg btn-block">Ainda com duvida?!</a>
			</div>
		</div>
	</div>

	<?php include_once('inc/footer.php'); ?>

	<?php include_once('inc/js.php'); ?>
	<script src="https://cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>
	<script src="js/tecnologia.js"></script>
</body>
</html>