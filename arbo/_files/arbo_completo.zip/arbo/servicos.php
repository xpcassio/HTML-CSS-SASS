<!DOCTYPE html>
<html lang="pt-br">
<head>
	<?php include_once('inc/favicon.php'); ?>

	<!-- SOCIAL -->
	<meta property="og:title" content="Arbo - Serviços" />
	<meta property="og:type" content="website" />
	<meta property="og:description" content="Realizamos projetos de energia solar fotovoltaica para a sua casa, empresa e indústria, propondo as melhores soluções do mercado." />
	<meta property="og:url" content="http://www.arbo.eco.br/servicos.php" />

	<meta property="og:image" content="http://www.arbo.eco.br/img/social.png" />
	<meta property="og:image:width" content="500" />
	<meta property="og:image:height" content="300" />

	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:image:alt" content="Banner logo Arbo">

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Arbo</title>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <?php include_once('inc/css.php'); ?>
</head>
<body>
	<div class="background background-pages">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<?php $temp_li_servico = "";include_once('inc/navbar.php'); ?>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-xs-12 text-center section-pages">
				<h1>Serviços</h1>
				<span></span>
				<p class="text-muted">Realizamos projetos de energia solar fotovoltaica para a sua casa, empresa e indústria, propondo as melhores soluções do mercado.</p>
			</div>
		</div>


		<!-- Nav tabs -->
		<div class="row">
			<div class="col-xs-12 col-sm-4">
				<a class="btn btn-default btn-lg btn-block servico-btn clearfix active" href="#tab_content-1" aria-controls="tab_content-1" role="tab" data-toggle="tab">
					<span class="circle">
						<img src="img/icons/cityscape.svg" alt="">
					</span>
					<span class="texto">Urbano</span>
				</a>
			</div>
			<div class="col-xs-12 col-sm-4">
				<a class="btn btn-default btn-lg btn-block servico-btn clearfix" href="#tab_content-2" aria-controls="tab_content-2" role="tab" data-toggle="tab">
					<span class="circle">
						<img src="img/icons/barn.svg" alt="">
					</span>
					<span class="texto">Rural</span>
				</a>
			</div>
			<div class="col-xs-12 col-sm-4">
				<a class="btn btn-default btn-lg btn-block servico-btn clearfix" href="#tab_content-3" aria-controls="tab_content-3" role="tab" data-toggle="tab">
					<span class="circle">
						<img src="img/icons/factory.svg" alt="">
					</span>
					<span class="texto">Empresarial</span>
				</a>
			</div>
			<!-- <div class="col-xs-12 col-sm-6 col-md-3">
				<a class="btn btn-default btn-lg btn-block servico-btn clearfix" href="#tab_content-4" aria-controls="tab_content-4" role="tab" data-toggle="tab" style="margin-bottom:0;">
					<span class="circle">
						<img src="img/icons/engineer.svg" alt="">
					</span>
					<span class="texto">Serviços Eletricos</span>
				</a>
			</div> -->
		</div>

		<!-- Tab panes -->
		<div class="row margin-top-50">
			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="tab_content-1">
					<?php include_once('inc/servicos_1.php'); ?>
				</div>
				<div role="tabpanel" class="tab-pane" id="tab_content-2">
					<?php include_once('inc/servicos_2.php'); ?>
				</div>
				<div role="tabpanel" class="tab-pane" id="tab_content-3">
					<?php include_once('inc/servicos_3.php'); ?>
				</div>
				<!-- <div role="tabpanel" class="tab-pane" id="tab_content-4">
					<?php include_once('servicos_4.php'); ?>
				</div> -->
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 text-center section-pages margin-top-50">
				<h1>Eficiência Energética</h1>
				<span></span>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 col-sm-6">
				<p>Uma análise detalhada e profissional de sua residência e/ou empresa, pode indicar diversas formas de fazer economia no consumo de energia elétrica.</p>
				<p>Desde a utilização de lâmpadas com alta eficiência energética e baixo consumo, passando por sistemas de automação e até orientações sobre isolamentos térmicos e pinturas especiais para diminuir a utilização de ar condicionado. Várias são as opções para que, ao final do mês, sua conta de energia apresente boas reduções, por isso contamos com profissionais experientes, prontos para auxiliar nesse sentido.</p>
			</div>
			<div class="col-xs-12 col-sm-6 text-right">
				<img class="img-headline img-responsive img-thumbnail" src="http://placehold.it/350x250">
			</div>
		</div>
	</div> <!-- /.container -->

	<?php include_once('inc/footer.php'); ?>

	<?php include_once('inc/js.php'); ?>
	<script src="js/servico.js"></script>
</body>
</html>