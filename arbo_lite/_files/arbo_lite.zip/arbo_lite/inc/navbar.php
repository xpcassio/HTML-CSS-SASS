<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="index.php">
				<img src="img/logo3.png" alt="logo">
			</a>
		</div>

		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li>
					<a class="links-menus" href="javascript:;" data-acc=".h1-servicos"><i class="fa fa-envira" aria-hidden="true"></i> Serviços</a>
				</li>
				<li>
					<a class="links-menus" href="javascript:;" data-acc=".h1-quemsomos"><i class="fa fa-question-circle-o fa-lg" aria-hidden="true"></i> Quem Somos</a>
				</li>
				<li>
					<a class="links-menus" href="javascript:;" data-acc=".h1-contato"><i class="fa fa-envelope-o" aria-hidden="true"></i> Contato</a>
				</li>
			</ul>
		</div>
	</div>	
</nav>