<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-xs-3 col-sm-2 col-md-1 div_arrow">
				<a href="#scrollTop">
					<i class="fa fa-arrow-circle-o-up" aria-hidden="true"></i>
				</a>
			</div>
			<div class="col-xs-9 col-sm-10 col-md-11">
				<div class="row">
					<div class="col-xs-12 col-sm-7 text-company">
						<p>&#169; <?=date('Y')?> EMAPA, Todos os direitos reservados.</p>
					</div>
					<div class="col-xs-12 col-sm-5 text-developer">
						<?php
							$temp_subject = "Desenvolvimento%20de%20Websites%20e%20Sistemas";
						?>
						<p>Desenvolvidor por <a href="mailto:xpcassio@gmail.com?Subject=<?=$temp_subject?>" target="_top">xpcassio</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>