<!DOCTYPE html>
<html lang="pt-br">
<head>
	<?php include_once('inc/favicon.php'); ?>
	<?php include_once('inc/social_tags.php'); ?>
	<?php include_once('inc/seo_tags.php'); ?>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Arbo &#149; Solução em Energia Solar</title>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <?php include_once('inc/css.php'); ?>

    <script defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBslf0LIjnUGBGwn6tD4GF3wNiwaBp_p0M"></script>
</head>
<body>

	<div class="background">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<?php include_once('inc/navbar.php'); ?>
				</div>

				<div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center div_text">
					<h2>Importação, Projetos e Soluções Energéticas</h2>
				</div>

				<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 div_links">
					<!-- <a href="tecnologia.php" class="btn btn-default btn-lg btn-block">Saiba mais</a> -->
					<a href="tel:9140068800">
						<i class="fa fa-phone" aria-hidden="true"></i>
						(91) 4006-8800
					</a>
					<a href="mailto:contato@arbo.eco.br?Subject=Contato Website Arbo">
						<i class="fa fa-envelope" aria-hidden="true"></i>
						<span class="visible-xs-inline">Email</span>
						<span class="hidden-xs">contato@arbo.eco.br</span>
					</a>
				</div> 
			</div>
		</div>
	</div>

	<div class="container">
		<!-- -------------------- PARTE 1 -------------------- -->
		<div class="row">
			<div class="col-xs-12 text-center section-pages">
				<h1 class="h1-servicos">Nossos Serviços</h1>
				<span></span>
				<p class="text-muted">Encontre os melhores serviços de Energia Solar em um só lugar.</p>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 col-sm-4 solucao-icon text-center">
				<div class="bola_colorida">
					<img src="img/icons/cityscape.svg" alt="">
				</div>
				<h3>Urbano</h3>
				<h4>Para baixar ou até zerar a sua conta de luz</h4>
				<p class="text-justify">Em nosso sistema urbano de auto produção de energia elétrica, você tem um sistema que atua em conjunto com a concessionária de energia locar (sistema on-grid). Desta forma a energia produzida quando não for usada na hora, ficara como crédito para usa-la na ausência de sol.</p>
				<p class="text-justify text-more">Nas cidades e áreas atendidas pelas concessionárias de energia elétrica, desde 17/04/2012 com a regulamentação trazida pela resolução normativa 482 da ANEEL (Agencia Nacional de Energia Elétrica), já é possível utilizarmos os sistemas chamado On-Grid que são conectados diretamente à rede de distribuição da concessionária local e não utilizam baterias para reservar energia para os períodos em que não há incidência solar. Nestes sistemas, os equipamentos chamados Inversores, tem a função de não só converter a corrente contínua fornecida pelas placas solares em corrente alternada que consumimos normalmente em nossas casas e empresas, mas também de sincronizar esta energia convertida com a freqüência da rede local com a finalidade de, nos momentos em que a geração local é maior do que o consumo, esta energia excedente seja entregue, após passar pelo medidor,à rede nacional de distribuição, gerando créditos em Kwh para a unidade geradora, que poderão ser utilizados em até 60 meses pela mesma ou por outra unidade consumidora que esteja registrada na mesma concessionária e com o mesmo CPF ou CNPJ.</p>
				<a class="btn btn-default btn-sm btn-readMore" href="javascript:;" role="button">Leia Mais</a>
			</div>
			<div class="col-xs-12 col-sm-4 solucao-icon text-center">
				<div class="bola_colorida">
					<img src="img/icons/factory.svg" alt="">
				</div>
				<h3>Empresarial</h3>
				<h4>Baixe seus custos com energia elétrica</h4>
				<p class="text-justify">Assim como no sistema urbano de auto produção de energia elétrica, no empresarial você tem um sistema que atua em conjunto com a concessionária de energia locar (sistema on-grid). Desta forma a energia produzida quando não for usada na hora, ficara como crédito para usa-la na ausência de sol. Diferentemente no urbano, o empresarial procura atender uma demanda maior de consumo de energia usando equipamentos de maior potência.</p>
				<p class="text-justify text-more">Nas cidades e áreas atendidas pelas concessionárias de energia elétrica, desde 17/04/2012 com a regulamentação trazida pela resolução normativa 482 da ANEEL (Agencia Nacional de Energia Elétrica), já é possível utilizarmos os sistemas chamado On-Grid que são conectados diretamente à rede de distribuição da concessionária local e não utilizam baterias para reservar energia para os períodos em que não há incidência solar. Nestes sistemas, os equipamentos chamados Inversores, tem a função de não só converter a corrente contínua fornecida pelas placas solares em corrente alternada que consumimos normalmente em nossas casas e empresas, mas também de sincronizar esta energia convertida com a freqüência da rede local com a finalidade de, nos momentos em que a geração local é maior do que o consumo, esta energia excedente seja entregue, após passar pelo medidor,à rede nacional de distribuição, gerando créditos em Kwh para a unidade geradora, que poderão ser utilizados em até 60 meses pela mesma ou por outra unidade consumidora que esteja registrada na mesma concessionária e com o mesmo CPF ou CNPJ. Nos casos específicos de grandes consumidores, deve haver uma análise junto a concessionária local sobre os valores e modalidade contratadas para que a geração seja aproveitada em sua totalidade.</p>
				<a class="btn btn-default btn-sm btn-readMore" href="javascript:;" role="button">Leia Mais</a>
			</div>
			<div class="col-xs-12 col-sm-4 solucao-icon text-center">
				<div class="bola_colorida">
					<img src="img/icons/barn.svg" alt="">
				</div>
				<h3>Rural</h3>
				<h4>Você não precisa de mais de geradores</h4>
				<p class="text-justify">Para regiões onde não chega energia elétrica através de linhóis, a alternativa é produzir energia através de geradores a gasolina ou disel. Hoje já existe uma alternativa muito melhor. A energia solar através do sistema off-grid (desconectado rede).Este é uma opção onde tem energia durante 24 horas por dia, silenciosa e com baixíssima manutenção.</p>
				<p class="text-justify text-more">Nos locais onde não existe uma rede de distribuição elétrica convencional, feita por uma distribuidora local, utilizamos o sistema chamado Of-Grid, nos quais, utilizando placas solares, controladores de carga, inversores de corrente e baterias, conseguimos suprir as necessidades de energia elétrica da unidade nos momentos em que há incidência de luz solar e, através da energia acumulada nas baterias, nos momentos em que a luz solar não alimenta os painéis. Estes sistemas são completamente independentes e devem possuir uma quantidade tal de baterias que consigam atender as características de cada local como a quantidade de luz solar, de chuvas e outras que podem comprometer o carregamento destas baterias afim de que possam fornecer energia quando não há carregamento.</p>
				<a class="btn btn-default btn-sm btn-readMore" href="javascript:;" role="button">Leia Mais</a>
			</div>
		</div>

		<!-- -------------------- PARTE 2 -------------------- -->
		<div class="row">
			<div class="col-xs-12 text-center section-pages margin-top-70">
				<h1 class="h1-quemsomos">Quem Somos?!</h1>
				<span></span>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-4">
				<h2 class="headline">Empresa</h2>
				A Arbo é uma empresa genuinamente paraense, que possui como missão a expansão do uso da Energia Solar no norte e nordeste do país. Nosso objetivo é levar esta tecnologia e serviço a todos aqueles que desejam esta tecnologia de geração de energia limpa, produzindo sua própria energia elétrica.
			</div>
			<div class="col-xs-12 col-sm-6 col-md-4 text-center">
				<img class="img-headline img-responsive img-thumbnail" src="img/img_princiapal.jpg">
			</div>
			<div class="col-xs-12 col-sm-6 col-md-4">
				<h2 class="headline">Missão / Objetivos</h2>
				Nossa missão é mostrar para o maior número de pessoas, que é possível, ter uma energia de maior qualidade, menor preço e sem danificar o meio ambiente. Cada raio de sol que incide eu seu telhado, poderia estar sendo usado para ascender suas lâmpadas ou ligar o seu acondicionado. Pensando assim, da uma dó olhar pela janela e ver o quando de energia que está deixando de ser aproveitada. Nós podemos mudar isso.
			</div>
		</div>

		<!-- -------------------- PARTE 3 -------------------- -->
		<div class="row">
			<div class="col-xs-12 text-center section-pages margin-top-70">
				<h1 class="h1-contato">Contato</h1>
				<span></span>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 col-md-6">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-12 div_endereco">
						<address>
							<strong>ARBO</strong><br>
							Rua Ó de Almeida 490 Conj. 1102<br>
							Belém, PA - Brasil<br>
							<i class="fa fa-phone"></i> <a href="tel:9140068800">(91) 4006-8800</a><br>
							<i class="fa fa-envelope"></i> <a href="mailto:contato@arbo.eco.br?Subject=Contato Website Arbo" target="_top">contato@arbo.eco.br</a>
						</address>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-12 div_mapa">
						<div id="map"></div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-6 div_form">
				<form id="formContato" novalidate>
					<div class="form-group">
						<input type="text" class="form-control input-lg" placeholder="Nome:" name="nome">
					</div>
					<div class="form-group">
						<input type="text" class="form-control input-lg" placeholder="Email:" name="email">
					</div>
					<div class="form-group">
						<input type="text" class="form-control input-lg" placeholder="Telefone:" name="telefone">
					</div>
					<div class="form-group">
						<textarea class="form-control input-lg" rows="5" placeholder="Mensagem:" name="mensagem"></textarea>
					</div>
					<button type="submit" class="btn btn-default btn-lg btn-block btn-formulario">Enviar</button>
				</form>
			</div>
			<div class="col-xs-12 div_alert">
				<div class="alert"></div>
			</div>
		</div>
	</div>

	<?php include_once('inc/footer.php'); ?>
	<?php include_once('inc/js.php'); ?>
</body>
</html>