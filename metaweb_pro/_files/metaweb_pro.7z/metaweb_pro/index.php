<!DOCTYPE>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<link rel="icon" href="img/favicon.ico" type="image/x-icon" />

	<title>Metaweb PRO</title>

	<!-- Arquivos CSS
	=================================== -->
	<? include_once("inc/inc_css.php"); ?>
</head>
<body>

	<div class="top_header">
		<div class="container">
			<div class="row">
				<div class="col-xs-8 col-sm-4">
					<span class="hidden-xs">Bem Vindo a Metaweb PRO</span>
					<span class="visible-xs-block">
						<a href="tel:9140038491" class="phone_link">
							<i class="fa fa-phone" aria-hidden="true"></i>
							(91) 4003.8491
						</a>
					</span>
				</div>
				<div class="col-xs-4 col-sm-8 text-right">
					<span class="hidden-xs">
						<a href="tel:9140038491" class="phone_link">
							<i class="fa fa-phone" aria-hidden="true"></i>
							(91) 4003.8491
						</a>
					</span>
					<span class="hidden-xs">
						<a href="mailto:contato@metaweb.com.br?Subject=Contato%20Metaweb%20PRO" class="email_link">
							<i class="fa fa-envelope-o" aria-hidden="true"></i>
							contato@metaweb.com.br
						</a>
					</span>
					<a href="https://twitter.com/MetawebHost" class="social_link" target="_blank"><i class="fa fa-twitter-square" aria-hidden="true" style="margin-right: 10px;"></i></a>
					<a href="https://www.facebook.com/MetawebHost?fref=ts" class="social_link" target="_blank"><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
	</div>

	<!-- <nav class="navbar navbar-default fluid_header">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#"><img src="../img/logo.png" alt="logo"></a>
			</div>

			<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li><a href="#">Link 1</a></li>
					<li><a href="#">Link 2</a></li>
					<li><a href="#">Link 3</a></li>
					<li><a href="#">Link 4</a></li>
					<li><a href="#">Link 5</a></li>
					<li><a href="#">Link 6</a></li>
				</ul>
			</div>
		</div>
	</nav> -->

	<div class="jumbotron overlay">
		<div class="container">
			<div class="col-xs-12 col-sm-8 no-padding">
				<img src="../img/logo.png" alt="logo">
				<h1>Metaweb, PRO!</h1>
				<p>Neste programa você poderá administrar todos os seus clientes e/ou contas Metaweb e ClicRegistro com facilidade e em um painel exclusivo.</p>
			</div>
		</div>
	</div>

	<div class="faixa_azul_metaweb">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-7 col-md-6 col-md-offset-1 text-center">
					<h3>Seja um dos primeiros a experimentar!</h3>
				</div>
				<div class="col-xs-12 col-sm-5 col-md-3 text-center">
					<a class="btn btn-default btn-lg btn-block btn-inscrever" href="#" role="button">Inscreva-se gratuitamente</a>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section-title text-center">
		            <h1>Acesso Exclusivo</h1>
		            <h2>À vantagens Incriveis</h2>
		        </div>

		        <div class="row">
		        	<div class="col-xs-12 col-sm-6 col-md-3">
		        		<div class="media media-metalweb">
		        			<div class="media-left">
		        				<i class="fa fa-list fa-4x" aria-hidden="true"></i>
		        			</div>
		        			<div class="media-body">
		        				<h4 class="media-heading">Gerenciamento de contas</h4>
		        				Com apenas um login único, gerencie toda as suas contas Metaweb e/ou ClicRegistro em um só lugar.
		        			</div>
		        		</div>
		        	</div>
		        	<div class="col-xs-12 col-sm-6 col-md-3">
		        		<div class="media media-metalweb">
		        			<div class="media-left">
		        				<i class="fa fa-shopping-cart fa-4x" aria-hidden="true"></i>
		        			</div>
		        			<div class="media-body">
		        				<h4 class="media-heading">Pagamentos</h4>
		        				Contrate ou pague serviços de forma simplificada para você ou seus clientes. Ou solicite a compra e deixe que seu cliente pague a conta. 
		        			</div>
		        		</div>
		        	</div>
		        	<div class="col-xs-12 col-sm-6 col-md-3">
		        		<div class="media media-metalweb">
		        			<div class="media-left">
		        				<i class="fa fa-percent fa-4x" aria-hidden="true"></i>
		        			</div>
		        			<div class="media-body">
		        				<h4 class="media-heading">Descontos Diferenciados</h4>
		        				Acesso a ofertas exclusivas e descontos especiais para ajudá-lo com seus clientes ou para conseguir novos.
		        			</div>
		        		</div>
		        	</div>
		        	<div class="col-xs-12 col-sm-6 col-md-3">
		        		<div class="media media-metalweb">
		        			<div class="media-left">
		        				<i class="fa fa-phone-square fa-4x" aria-hidden="true"></i>
		        			</div>
		        			<div class="media-body">
		        				<h4 class="media-heading">Suporte Especializado</h4>
		        				Conectamos você a um suporte tecnico especializado, altamente treinados para lhe ajudar com todos os seus problemas técnicos.
		        			</div>
		        		</div>
		        	</div>
		        </div>
			</div>
		</div>

		<div class="row div-cadastro" style="margin-top:50px;">
			<div class="col-xs-12">
				<div class="section-title text-center">
		            <h1>Inscreva-se gratuitamente</h1>
		            <h2>E mantenha-se atualizado</h2>
		        </div>

		        <div class="row">
					<form id="form_cadastro" novalidate>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3">
							<div class="form-group">
								<label class="sr-only"></label>
								<input type="text" name="nome" class="form-control input-lg" placeholder="Nome completo" required>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3">
							<div class="form-group">
								<label class="sr-only"></label>
								<input type="text" name="email" class="form-control input-lg" placeholder="Email" required>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3">
							<div class="form-group">
								<label class="sr-only"></label>
								<input type="text" name="telefone" class="form-control input-lg" placeholder="Telefone" required>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3">
							<div class="form-group">
								<label class="sr-only"></label>
								<select name="atuacao" class="form-control input-lg" required>
									<option value="" class="select-hr">Área de atuação?</option>
									<option value="programador">Programador</option>
									<option value="design">Design</option>
									<option value="agencia">Agência de desenvolvimento</option>
									<option value="ti">Profissional de TI</option>
									<option value="entusiasta">Programador/Design Entusiasta</option>
									<option value="outro">Outro</option>
								</select>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3" style="display:none;">
							<div class="form-group">
								<label class="sr-only"></label>
								<input type="text" name="atuacao_outro" class="form-control input-lg" placeholder="Qual sua profissão?">
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3">
							<div class="form-group">
								<label class="sr-only"></label>
								<select name="admin_sites" class="form-control input-lg" required>
									<option value="" class="select-hr">Quantos sites você administra?</option>
									<option value="1">1 site</option>
									<option value="2">2 sites</option>
									<option value="3">3 sites</option>
									<option value="4">4 sites</option>
									<option value="5a10">5 a 10 sites</option>
									<option value="11a15">11 a 15 sites</option>
									<option value="16+">Mais de 15 sites</option>
									<option value="0">Não administro sites</option>
								</select>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3">
							<div class="form-group">
								<label class="sr-only"></label>
								<select name="admin_sites_extra" class="form-control input-lg" required>
									<option value="" class="select-hr">Onde seus serviços estão hospedados?</option>
									<option value="metaweb">Metaweb/ClicRegistro</option>
									<option value="outros">Outra Empresa</option>
									<option value="nosDois">Metaweb/ClicRegistro e em outras empresas</option>
									<option value="nenhum">Não tenho serviços em nenhuma empresa</option>
									<option value="naoSabe">Não sei informar</option>
								</select>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3">
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" name="envioEmail" value="sim" required>
										Você autoriza o envio de email com atualiações e novidades da metaweb e parceiros?
									</label>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-sm-offset-3">
							<input class="btn btn-default btn-block btn-lg btn-cadastrar" type="submit" value="Cadastrar">
						</div>
						<div id="div_alertGeral" class="col-xs-12 col-sm-6 col-sm-offset-3">
							<div class="alert alert-success" role="alert"></div>		
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-8">
					<p>Copyright © 2002-<?=date("Y");?> Metaweb Host Center. Proibida reprodução ou utilização a qualquer título, sob as penas da lei. </p>
				</div>
				<div class="col-xs-12 col-sm-4 div-abra">
					<a href="#"><img src="img/abrahosting.png" alt=""></a>
				</div>
			</div>
		</div>
	</footer>

	<!-- Arquivos Jsvascript
	=================================== -->
	<? include_once("inc/inc_js.php"); ?>
</body>
</html>